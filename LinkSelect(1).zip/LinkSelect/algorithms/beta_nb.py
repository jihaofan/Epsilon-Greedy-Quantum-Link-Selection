import math
import numpy as np
import statsmodels.stats.api as sms


def beta_elimination_network_benchmarking(network, path_list, bounces):
    # Initialization
    L = len(path_list)
    print(f"path_list: {path_list}")
    active_set = path_list
    confidence = 0.99
    N = 4
    cost = 0
    c=0
    sample_times = {}
    for i in bounces:
        sample_times[i] = N


    data = {path: [] for path in path_list}
    
    ucb = {}
    lcb = {}
   
    while len(active_set) > 1:
        
        c+=1
        for path in active_set:
            for j in range(5):
                p, bounces_num = network.benchmark_path(path, bounces, sample_times)
                data[path].append(p)
                cost += bounces_num
                
            dataPath = np.array(data[path])
            desc_stats = sms.DescrStatsW(dataPath)
            lcb[path],ucb[path] = desc_stats.tconfint_mean(alpha=1-confidence)    
           
            print(f"data[{path}] = {data[path]}")
            print(f"ucb[{path}] = {ucb[path]}")
            print(f"lcb[{path}] = {lcb[path]}")
            
        new_active_set = []
        for path1 in active_set:
            ok = True
            for path2 in active_set:
                if path1 != path2 and ucb[path1] < lcb[path2]:
                    ok = False
                    break
            if ok:
                new_active_set.append(path1)

        active_set = new_active_set
        print(f"current active set: {active_set}")
        print(f"Length of active set: {len(active_set)}")
        print("***************************")

    assert len(active_set) == 1
    best_path = active_set[0]
    correctness = best_path == network.best_path
    
    p = (lcb[best_path]+ucb[best_path])/2
    best_path_fidelity = p + (1 - p) / 2
    print(f"beta nb: Best path: {best_path},  cost: {cost}")
    return correctness, cost, best_path_fidelity
