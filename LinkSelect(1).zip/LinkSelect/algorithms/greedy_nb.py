import math
import numpy as np


def greedy_elimination_network_benchmarking(network, path_list, bounces):
    # Initialization
    L = len(path_list)
    print(f"path_list: {path_list}")
    active_set = path_list
    C = 25
    N = 20
    cost = 0
    epsilon = 0.1
    sample_times = {}
    for i in bounces:
        sample_times[i] = N

    mean = {path: 0 for path in path_list}
    n = {path: 1 for path in path_list}
    t = 1
    
    for path in active_set:
        p, bounces_num = network.benchmark_path(path, bounces, sample_times)
        cost+=bounces_num
        mean[path]=p
        
    
    for i in bounces:
        sample_times[i] = 4
    
    while C > 1:
        C-=1
        t+=1
        if np.random.rand()<epsilon:
            chosen_path = np.random.choice(active_set)
        else:
            chosen_path = max(active_set, key=lambda path: mean[path])
            
        p, bounces_num = network.benchmark_path(chosen_path, bounces, sample_times)
        cost += bounces_num
        mean[chosen_path] = (mean[chosen_path] * n[chosen_path] + p) / (n[chosen_path] + 1)
        n[chosen_path] += 1
        
        print(f"Path: {chosen_path}, Mean: {mean[chosen_path]}")
        
            
            

    # assert len(active_set) == 1
    best_path = max(active_set, key=lambda path: mean[path])
    correctness = best_path == network.best_path
    # print(f"Succ Elim NB: Best path: {best_path}, estimated parameter p: {mean[best_path]}, cost: {cost}")
    # estimated_fidelity = {}
    # for path in path_list:
    #     p = mean[path]
    #     # Convert the estimated depolarizing parameter `p` into fidelity
    #     estimated_fidelity[path] = p + (1 - p) / 2
    p=mean[best_path]
    best_path_fidelity = p + (1 - p) / 2
    return correctness, cost, best_path_fidelity
